op_version_set = 1
def forward(self,
    input: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
  _0 = self.linear
  weight = _0.weight
  bias = _0.bias
  _1 = torch.addmm(bias, input, torch.t(weight), beta=1, alpha=1)
  _2 = torch.gt(torch.sum(_1, dtype=None), 0)
  if bool(_2):
    _3 = _1
  else:
    _3 = torch.neg(_1)
  _4 = torch.tanh(torch.add(_3, h, alpha=1))
  return (_4, _4)
